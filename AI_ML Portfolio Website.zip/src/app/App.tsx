import { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Badge } from './components/ui/badge';
import { Input } from './components/ui/input';
import { Textarea } from './components/ui/textarea';
import { Separator } from './components/ui/separator';
import { Label } from './components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './components/ui/dialog';
import {
  Mail,
  Linkedin,
  Github,
  MapPin,
  Download,
  ExternalLink,
  Code2,
  Briefcase,
  Award,
  ChevronRight,
  Menu,
  X,
  Edit,
  Save,
  Plus,
  Trash2,
  Settings
} from 'lucide-react';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);

  // Editable Profile Data
  const [profileData, setProfileData] = useState({
    fullName: "Thulile Phoswa",
    title: "AI & Machine Learning Developer",
    intro: "Passionate about building intelligent systems and leveraging data to solve complex problems.",
    profileImage: "",
    about: "I'm a dedicated AI/ML developer with a strong foundation in computer science and a passion for artificial intelligence. My journey in tech has been driven by curiosity and a desire to create innovative solutions that make a difference. I specialize in developing machine learning models, neural networks, and intelligent systems that transform data into actionable insights.",
    email: "thulile.phoswa@example.com",
    linkedin: "linkedin.com/in/thulilephoswa",
    github: "github.com/thulilephoswa",
    location: "Johannesburg, South Africa"
  });

  // Skills Data
  const [skills, setSkills] = useState([
    { category: "Programming Languages", items: ["Python", "JavaScript", "Java", "C++", "SQL"] },
    { category: "AI/ML Frameworks", items: ["TensorFlow", "PyTorch", "Scikit-learn", "Keras", "OpenCV"] },
    { category: "Web Development", items: ["React", "Node.js", "Express", "MongoDB", "PostgreSQL"] },
    { category: "Tools & Technologies", items: ["Git", "Docker", "AWS", "Google Cloud", "Jupyter"] },
    { category: "Data Science", items: ["Pandas", "NumPy", "Matplotlib", "Seaborn", "Data Visualization"] }
  ]);

  // Projects Data
  const [projects, setProjects] = useState([
    {
      id: 1,
      title: "AI Image Classification System",
      description: "Developed a deep learning model using CNN to classify images with 95% accuracy. Implemented transfer learning with ResNet-50.",
      image: "",
      technologies: ["Python", "TensorFlow", "Keras", "OpenCV"],
      github: "https://github.com/yourusername/project1",
      demo: "https://demo-link.com"
    },
    {
      id: 2,
      title: "Natural Language Processing Chatbot",
      description: "Created an intelligent chatbot using NLP techniques and transformer models for customer service automation.",
      image: "",
      technologies: ["Python", "NLTK", "Transformers", "FastAPI"],
      github: "https://github.com/yourusername/project2",
      demo: "https://demo-link.com"
    },
    {
      id: 3,
      title: "Predictive Analytics Dashboard",
      description: "Built a full-stack web application for real-time data analytics and predictive modeling using machine learning.",
      image: "",
      technologies: ["React", "Python", "Scikit-learn", "D3.js"],
      github: "https://github.com/yourusername/project3",
      demo: "https://demo-link.com"
    }
  ]);

  // Experience Data
  const [experiences, setExperiences] = useState([
    {
      id: 1,
      title: "Machine Learning Engineer",
      company: "Tech Innovations Inc.",
      type: "Full-time",
      startDate: "Jan 2023",
      endDate: "Present",
      description: "Leading the development of AI-powered solutions for enterprise clients.",
      responsibilities: "Designed and implemented machine learning models for production systems\nCollaborated with cross-functional teams to deploy AI solutions\nOptimized model performance and reduced inference time by 40%",
      technologies: "Python, TensorFlow, AWS, Docker"
    },
    {
      id: 2,
      title: "Junior Data Scientist",
      company: "Data Analytics Corp",
      type: "Full-time",
      startDate: "Jun 2021",
      endDate: "Dec 2022",
      description: "Worked on data analysis and machine learning projects for various industries.",
      responsibilities: "Developed predictive models for customer churn analysis\nCreated data visualizations and reports for stakeholders\nConducted A/B testing and statistical analysis",
      technologies: "Python, Scikit-learn, SQL, Tableau"
    }
  ]);

  // Certifications Data
  const [certifications, setCertifications] = useState([
    { id: 1, name: "TensorFlow Developer Certificate", issuer: "Google", year: "2023" },
    { id: 2, name: "AWS Machine Learning Specialty", issuer: "Amazon", year: "2023" },
    { id: 3, name: "Deep Learning Specialization", issuer: "Coursera", year: "2022" },
    { id: 4, name: "Python for Data Science", issuer: "IBM", year: "2021" }
  ]);

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: ""
  });

  // Edit dialog states
  const [editingProject, setEditingProject] = useState<any>(null);
  const [editingExperience, setEditingExperience] = useState<any>(null);
  const [editingCert, setEditingCert] = useState<any>(null);
  const [editingSkill, setEditingSkill] = useState<any>(null);

  // Refs for smooth scrolling
  const homeRef = useRef<HTMLElement>(null);
  const aboutRef = useRef<HTMLElement>(null);
  const skillsRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLElement>(null);
  const experienceRef = useRef<HTMLElement>(null);
  const resumeRef = useRef<HTMLElement>(null);
  const contactRef = useRef<HTMLElement>(null);

  const scrollToSection = (ref: React.RefObject<HTMLElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Contact form submitted:", contactForm);
    alert("Thank you for your message! I'll get back to you soon.");
    setContactForm({ name: "", email: "", message: "" });
  };

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      console.log("Resume uploaded:", file.name);
      alert(`Resume "${file.name}" uploaded successfully!`);
    }
  };

  const handleProfileImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileData({ ...profileData, profileImage: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  // Add new project
  const addProject = () => {
    const newProject = {
      id: Date.now(),
      title: "New Project",
      description: "Project description here",
      image: "",
      technologies: ["Technology"],
      github: "https://github.com/yourusername/project",
      demo: "https://demo-link.com"
    };
    setProjects([...projects, newProject]);
  };

  // Update project
  const updateProject = (updatedProject: any) => {
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
    setEditingProject(null);
  };

  // Delete project
  const deleteProject = (id: number) => {
    if (confirm("Are you sure you want to delete this project?")) {
      setProjects(projects.filter(p => p.id !== id));
    }
  };

  // Add new experience
  const addExperience = () => {
    const newExp = {
      id: Date.now(),
      title: "Job Title",
      company: "Company Name",
      type: "Full-time",
      startDate: "Month Year",
      endDate: "Present",
      description: "Job description",
      responsibilities: "Responsibility 1\nResponsibility 2",
      technologies: "Tech1, Tech2"
    };
    setExperiences([...experiences, newExp]);
  };

  // Update experience
  const updateExperience = (updatedExp: any) => {
    setExperiences(experiences.map(e => e.id === updatedExp.id ? updatedExp : e));
    setEditingExperience(null);
  };

  // Delete experience
  const deleteExperience = (id: number) => {
    if (confirm("Are you sure you want to delete this experience?")) {
      setExperiences(experiences.filter(e => e.id !== id));
    }
  };

  // Add new certification
  const addCertification = () => {
    const newCert = {
      id: Date.now(),
      name: "Certification Name",
      issuer: "Issuing Organization",
      year: new Date().getFullYear().toString()
    };
    setCertifications([...certifications, newCert]);
  };

  // Update certification
  const updateCertification = (updatedCert: any) => {
    setCertifications(certifications.map(c => c.id === updatedCert.id ? updatedCert : c));
    setEditingCert(null);
  };

  // Delete certification
  const deleteCertification = (id: number) => {
    if (confirm("Are you sure you want to delete this certification?")) {
      setCertifications(certifications.filter(c => c.id !== id));
    }
  };

  // Add new skill category
  const addSkillCategory = () => {
    const newSkill = {
      category: "New Category",
      items: ["Skill 1", "Skill 2"]
    };
    setSkills([...skills, newSkill]);
  };

  // Update skill category
  const updateSkillCategory = (index: number, updatedSkill: any) => {
    const newSkills = [...skills];
    newSkills[index] = updatedSkill;
    setSkills(newSkills);
    setEditingSkill(null);
  };

  // Delete skill category
  const deleteSkillCategory = (index: number) => {
    if (confirm("Are you sure you want to delete this skill category?")) {
      setSkills(skills.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 text-white dark">
      {/* Edit Mode Toggle */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setEditMode(!editMode)}
          className={`rounded-full w-14 h-14 shadow-2xl ${
            editMode
              ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700'
              : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
          }`}
          title={editMode ? "Save & Exit Edit Mode" : "Enter Edit Mode"}
        >
          {editMode ? <Save className="h-6 w-6" /> : <Edit className="h-6 w-6" />}
        </Button>
      </div>

      {/* Edit Mode Indicator */}
      {editMode && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-green-600 to-emerald-600 px-6 py-3 rounded-full shadow-2xl animate-pulse">
          <div className="flex items-center gap-2">
            <Edit className="h-5 w-5" />
            <span className="font-bold">Edit Mode Active</span>
          </div>
        </div>
      )}

      {/* Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-lg border-b border-purple-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-2"
            >
              <Code2 className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                TP
              </span>
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection(homeRef)} className="hover:text-purple-400 transition-colors">Home</button>
              <button onClick={() => scrollToSection(aboutRef)} className="hover:text-purple-400 transition-colors">About</button>
              <button onClick={() => scrollToSection(skillsRef)} className="hover:text-purple-400 transition-colors">Skills</button>
              <button onClick={() => scrollToSection(projectsRef)} className="hover:text-purple-400 transition-colors">Projects</button>
              <button onClick={() => scrollToSection(experienceRef)} className="hover:text-purple-400 transition-colors">Experience</button>
              <button onClick={() => scrollToSection(resumeRef)} className="hover:text-purple-400 transition-colors">Resume</button>
              <button onClick={() => scrollToSection(contactRef)} className="hover:text-purple-400 transition-colors">Contact</button>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden bg-slate-900/95 backdrop-blur-lg border-t border-purple-500/20"
          >
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => scrollToSection(homeRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Home</button>
              <button onClick={() => scrollToSection(aboutRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">About</button>
              <button onClick={() => scrollToSection(skillsRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Skills</button>
              <button onClick={() => scrollToSection(projectsRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Projects</button>
              <button onClick={() => scrollToSection(experienceRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Experience</button>
              <button onClick={() => scrollToSection(resumeRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Resume</button>
              <button onClick={() => scrollToSection(contactRef)} className="block w-full text-left py-2 hover:text-purple-400 transition-colors">Contact</button>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section ref={homeRef} className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="max-w-6xl mx-auto text-center">
          {editMode && (
            <Dialog>
              <DialogTrigger asChild>
                <Button className="mb-4 bg-blue-600 hover:bg-blue-700">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Profile Info
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-900 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Edit Profile Information</DialogTitle>
                  <DialogDescription>Update your personal information and contact details.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Full Name</Label>
                    <Input
                      value={profileData.fullName}
                      onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>Professional Title</Label>
                    <Input
                      value={profileData.title}
                      onChange={(e) => setProfileData({ ...profileData, title: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>Short Introduction</Label>
                    <Textarea
                      value={profileData.intro}
                      onChange={(e) => setProfileData({ ...profileData, intro: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>About Me</Label>
                    <Textarea
                      value={profileData.about}
                      onChange={(e) => setProfileData({ ...profileData, about: e.target.value })}
                      className="bg-slate-800 border-purple-500/30 min-h-[150px]"
                    />
                  </div>
                  <div>
                    <Label>Email</Label>
                    <Input
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>LinkedIn</Label>
                    <Input
                      value={profileData.linkedin}
                      onChange={(e) => setProfileData({ ...profileData, linkedin: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>GitHub</Label>
                    <Input
                      value={profileData.github}
                      onChange={(e) => setProfileData({ ...profileData, github: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                  <div>
                    <Label>Location</Label>
                    <Input
                      value={profileData.location}
                      onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                      className="bg-slate-800 border-purple-500/30"
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8 relative inline-block"
          >
            <div className="relative">
              <Avatar className="h-40 w-40 border-4 border-purple-500/50 shadow-2xl shadow-purple-500/50 mx-auto">
                <AvatarImage src={profileData.profileImage} alt={profileData.fullName} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-4xl">
                  {profileData.fullName.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <label
                htmlFor="profile-upload"
                className="absolute bottom-0 right-0 bg-purple-600 hover:bg-purple-700 rounded-full p-2 cursor-pointer transition-colors shadow-lg"
              >
                <Download className="h-4 w-4" />
                <input
                  id="profile-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleProfileImageUpload}
                />
              </label>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"
          >
            {profileData.fullName}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-2xl md:text-3xl text-purple-300 mb-4"
          >
            {profileData.title}
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto"
          >
            {profileData.intro}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex flex-wrap gap-4 justify-center"
          >
            <Button
              onClick={() => scrollToSection(projectsRef)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-6"
            >
              View Projects
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              onClick={() => scrollToSection(resumeRef)}
              variant="outline"
              className="border-purple-500 text-purple-300 hover:bg-purple-500/10 px-8 py-6"
            >
              <Download className="mr-2 h-5 w-5" />
              Download Resume
            </Button>
            <Button
              onClick={() => scrollToSection(contactRef)}
              variant="outline"
              className="border-blue-500 text-blue-300 hover:bg-blue-500/10 px-8 py-6"
            >
              Contact Me
            </Button>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section ref={aboutRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              About Me
            </h2>
            <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-8 shadow-2xl shadow-purple-500/10">
              <p className="text-gray-300 text-lg leading-relaxed">
                {profileData.about}
              </p>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Skills Section */}
      <section ref={skillsRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-center gap-4 mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Skills & Technologies
              </h2>
              {editMode && (
                <Button onClick={addSkillCategory} size="sm" className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skills.map((skillGroup, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: editMode ? 1 : 1.05 }}
                >
                  <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 h-full shadow-lg hover:shadow-purple-500/20 transition-all">
                    {editMode && (
                      <div className="flex gap-2 mb-3">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="flex-1 border-blue-500 text-blue-300">
                              <Edit className="h-3 w-3 mr-1" />
                              Edit
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-purple-500/30 text-white">
                            <DialogHeader>
                              <DialogTitle>Edit Skill Category</DialogTitle>
                              <DialogDescription>Update the category name and skills.</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label>Category Name</Label>
                                <Input
                                  defaultValue={skillGroup.category}
                                  onChange={(e) => {
                                    const updated = { ...skillGroup, category: e.target.value };
                                    updateSkillCategory(index, updated);
                                  }}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                              <div>
                                <Label>Skills (comma-separated)</Label>
                                <Textarea
                                  defaultValue={skillGroup.items.join(', ')}
                                  onChange={(e) => {
                                    const items = e.target.value.split(',').map(s => s.trim()).filter(s => s);
                                    const updated = { ...skillGroup, items };
                                    updateSkillCategory(index, updated);
                                  }}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteSkillCategory(index)}
                          className="border-red-500 text-red-300 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    <h3 className="text-xl font-bold mb-4 text-purple-300">
                      {skillGroup.category}
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.items.map((skill, idx) => (
                        <Badge
                          key={idx}
                          className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-purple-500/50 text-purple-200 hover:from-blue-600/30 hover:to-purple-600/30"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section ref={projectsRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-center gap-4 mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Featured Projects
              </h2>
              {editMode && (
                <Button onClick={addProject} size="sm" className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: editMode ? 1 : 1.05 }}
                >
                  <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 overflow-hidden h-full flex flex-col shadow-lg hover:shadow-purple-500/20 transition-all">
                    <div className="h-48 bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center">
                      {project.image ? (
                        <img src={project.image} alt={project.title} className="w-full h-full object-cover" />
                      ) : (
                        <Code2 className="h-20 w-20 text-purple-400/50" />
                      )}
                    </div>
                    <div className="p-6 flex-1 flex flex-col">
                      {editMode && (
                        <div className="flex gap-2 mb-3">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline" className="flex-1 border-blue-500 text-blue-300">
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-slate-900 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Edit Project</DialogTitle>
                                <DialogDescription>Update project details, technologies, and links.</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Project Title</Label>
                                  <Input
                                    defaultValue={project.title}
                                    onBlur={(e) => updateProject({ ...project, title: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>Description</Label>
                                  <Textarea
                                    defaultValue={project.description}
                                    onBlur={(e) => updateProject({ ...project, description: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>Technologies (comma-separated)</Label>
                                  <Input
                                    defaultValue={project.technologies.join(', ')}
                                    onBlur={(e) => {
                                      const techs = e.target.value.split(',').map(t => t.trim()).filter(t => t);
                                      updateProject({ ...project, technologies: techs });
                                    }}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>GitHub URL</Label>
                                  <Input
                                    defaultValue={project.github}
                                    onBlur={(e) => updateProject({ ...project, github: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>Demo URL</Label>
                                  <Input
                                    defaultValue={project.demo}
                                    onBlur={(e) => updateProject({ ...project, demo: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>Image URL</Label>
                                  <Input
                                    defaultValue={project.image}
                                    onBlur={(e) => updateProject({ ...project, image: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                    placeholder="Enter image URL or upload"
                                  />
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteProject(project.id)}
                            className="border-red-500 text-red-300 hover:bg-red-500/10"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <h3 className="text-xl font-bold mb-3 text-purple-300">
                        {project.title}
                      </h3>
                      <p className="text-gray-400 mb-4 flex-1">
                        {project.description}
                      </p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.technologies.map((tech, idx) => (
                          <Badge
                            key={idx}
                            variant="outline"
                            className="border-blue-500/50 text-blue-300"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-purple-500 text-purple-300 hover:bg-purple-500/10 flex-1"
                          onClick={() => window.open(project.github, '_blank')}
                        >
                          <Github className="mr-2 h-4 w-4" />
                          GitHub
                        </Button>
                        <Button
                          size="sm"
                          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 flex-1"
                          onClick={() => window.open(project.demo, '_blank')}
                        >
                          <ExternalLink className="mr-2 h-4 w-4" />
                          Demo
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Experience Section */}
      <section ref={experienceRef} className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-center gap-4 mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Professional Experience
              </h2>
              {editMode && (
                <Button onClick={addExperience} size="sm" className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="space-y-8">
              {experiences.map((exp, index) => (
                <motion.div
                  key={exp.id}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-8 shadow-lg hover:shadow-purple-500/20 transition-all">
                    {editMode && (
                      <div className="flex gap-2 mb-4">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="border-blue-500 text-blue-300">
                              <Edit className="h-3 w-3 mr-1" />
                              Edit Experience
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-slate-900 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>Edit Experience</DialogTitle>
                              <DialogDescription>Update your work experience details and responsibilities.</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label>Job Title</Label>
                                <Input
                                  defaultValue={exp.title}
                                  onBlur={(e) => updateExperience({ ...exp, title: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                              <div>
                                <Label>Company</Label>
                                <Input
                                  defaultValue={exp.company}
                                  onBlur={(e) => updateExperience({ ...exp, company: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                              <div>
                                <Label>Employment Type</Label>
                                <Input
                                  defaultValue={exp.type}
                                  onBlur={(e) => updateExperience({ ...exp, type: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>Start Date</Label>
                                  <Input
                                    defaultValue={exp.startDate}
                                    onBlur={(e) => updateExperience({ ...exp, startDate: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                                <div>
                                  <Label>End Date</Label>
                                  <Input
                                    defaultValue={exp.endDate}
                                    onBlur={(e) => updateExperience({ ...exp, endDate: e.target.value })}
                                    className="bg-slate-800 border-purple-500/30"
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>Description</Label>
                                <Textarea
                                  defaultValue={exp.description}
                                  onBlur={(e) => updateExperience({ ...exp, description: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                              <div>
                                <Label>Responsibilities (one per line)</Label>
                                <Textarea
                                  defaultValue={exp.responsibilities}
                                  onBlur={(e) => updateExperience({ ...exp, responsibilities: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30 min-h-[100px]"
                                />
                              </div>
                              <div>
                                <Label>Technologies (comma-separated)</Label>
                                <Input
                                  defaultValue={exp.technologies}
                                  onBlur={(e) => updateExperience({ ...exp, technologies: e.target.value })}
                                  className="bg-slate-800 border-purple-500/30"
                                />
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteExperience(exp.id)}
                          className="border-red-500 text-red-300 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </Button>
                      </div>
                    )}
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                      <div className="flex items-start gap-4 mb-4 md:mb-0">
                        <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-3 rounded-lg">
                          <Briefcase className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-purple-300">
                            {exp.title}
                          </h3>
                          <p className="text-xl text-gray-300">{exp.company}</p>
                          <Badge className="mt-2 bg-blue-600/20 border-blue-500/50 text-blue-300">
                            {exp.type}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-gray-400">
                        {exp.startDate} - {exp.endDate}
                      </div>
                    </div>
                    <p className="text-gray-300 mb-4">{exp.description}</p>
                    <div className="mb-4">
                      <h4 className="font-bold text-purple-300 mb-2">Key Responsibilities:</h4>
                      <ul className="list-disc list-inside space-y-1 text-gray-300">
                        {exp.responsibilities.split('\n').filter((r: string) => r.trim()).map((resp: string, idx: number) => (
                          <li key={idx}>{resp}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.split(',').map((tech: string, idx: number) => (
                        <Badge
                          key={idx}
                          variant="outline"
                          className="border-purple-500/50 text-purple-300"
                        >
                          {tech.trim()}
                        </Badge>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Resume Section */}
      <section ref={resumeRef} className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Resume / CV
            </h2>
            <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-8 shadow-2xl shadow-purple-500/10">
              <div className="text-center">
                <Download className="h-16 w-16 text-purple-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4 text-purple-300">Download My Resume</h3>
                <p className="text-gray-300 mb-6">
                  Get a comprehensive overview of my skills, experience, and achievements.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Button
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-6"
                  >
                    <Download className="mr-2 h-5 w-5" />
                    Download Resume
                  </Button>
                  <div className="relative">
                    <input
                      id="resume-upload"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      className="hidden"
                      onChange={handleResumeUpload}
                    />
                    <Button
                      variant="outline"
                      className="border-purple-500 text-purple-300 hover:bg-purple-500/10 px-8 py-6"
                      onClick={() => document.getElementById('resume-upload')?.click()}
                    >
                      Upload New Resume
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Certifications */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-20"
        >
          <div className="flex items-center justify-center gap-4 mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Certifications & Achievements
            </h2>
            {editMode && (
              <Button onClick={addCertification} size="sm" className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4" />
              </Button>
            )}
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-6xl mx-auto">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: editMode ? 1 : 1.05 }}
              >
                <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 shadow-lg hover:shadow-purple-500/20 transition-all">
                  {editMode && (
                    <div className="flex gap-2 mb-3">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button size="sm" variant="outline" className="flex-1 border-blue-500 text-blue-300">
                            <Edit className="h-3 w-3 mr-1" />
                            Edit
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-slate-900 border-purple-500/30 text-white">
                          <DialogHeader>
                            <DialogTitle>Edit Certification</DialogTitle>
                            <DialogDescription>Update certification name, issuer, and year.</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Certification Name</Label>
                              <Input
                                defaultValue={cert.name}
                                onBlur={(e) => updateCertification({ ...cert, name: e.target.value })}
                                className="bg-slate-800 border-purple-500/30"
                              />
                            </div>
                            <div>
                              <Label>Issuing Organization</Label>
                              <Input
                                defaultValue={cert.issuer}
                                onBlur={(e) => updateCertification({ ...cert, issuer: e.target.value })}
                                className="bg-slate-800 border-purple-500/30"
                              />
                            </div>
                            <div>
                              <Label>Year</Label>
                              <Input
                                defaultValue={cert.year}
                                onBlur={(e) => updateCertification({ ...cert, year: e.target.value })}
                                className="bg-slate-800 border-purple-500/30"
                              />
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteCertification(cert.id)}
                        className="border-red-500 text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  <div className="flex items-start gap-4">
                    <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-3 rounded-lg">
                      <Award className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-purple-300 mb-2">
                        {cert.name}
                      </h3>
                      <p className="text-gray-300">{cert.issuer}</p>
                      <Badge className="mt-2 bg-blue-600/20 border-blue-500/50 text-blue-300">
                        {cert.year}
                      </Badge>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Contact Section */}
      <section ref={contactRef} className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Get In Touch
            </h2>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 shadow-lg hover:shadow-purple-500/20 transition-all">
                <Mail className="h-8 w-8 text-purple-400 mb-4" />
                <h3 className="font-bold text-purple-300 mb-2">Email</h3>
                <p className="text-gray-300">{profileData.email}</p>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 shadow-lg hover:shadow-purple-500/20 transition-all">
                <Linkedin className="h-8 w-8 text-purple-400 mb-4" />
                <h3 className="font-bold text-purple-300 mb-2">LinkedIn</h3>
                <p className="text-gray-300">{profileData.linkedin}</p>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 shadow-lg hover:shadow-purple-500/20 transition-all">
                <Github className="h-8 w-8 text-purple-400 mb-4" />
                <h3 className="font-bold text-purple-300 mb-2">GitHub</h3>
                <p className="text-gray-300">{profileData.github}</p>
              </Card>

              <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-6 shadow-lg hover:shadow-purple-500/20 transition-all">
                <MapPin className="h-8 w-8 text-purple-400 mb-4" />
                <h3 className="font-bold text-purple-300 mb-2">Location</h3>
                <p className="text-gray-300">{profileData.location}</p>
              </Card>
            </div>

            <Card className="bg-slate-900/50 backdrop-blur-lg border-purple-500/30 p-8 shadow-2xl shadow-purple-500/10">
              <h3 className="text-2xl font-bold mb-6 text-purple-300">Send Me a Message</h3>
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Name</label>
                  <Input
                    placeholder="Your Name"
                    value={contactForm.name}
                    onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                    className="bg-slate-800/50 border-purple-500/30 text-white placeholder:text-gray-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Email</label>
                  <Input
                    type="email"
                    placeholder="your.email@example.com"
                    value={contactForm.email}
                    onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                    className="bg-slate-800/50 border-purple-500/30 text-white placeholder:text-gray-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-gray-300">Message</label>
                  <Textarea
                    placeholder="Your message..."
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    className="bg-slate-800/50 border-purple-500/30 text-white placeholder:text-gray-500 min-h-[150px]"
                    required
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-6"
                >
                  Send Message
                </Button>
              </form>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950/80 backdrop-blur-lg border-t border-purple-500/20 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <Code2 className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                {profileData.fullName}
              </span>
            </div>

            <div className="flex gap-6">
              <a
                href={`mailto:${profileData.email}`}
                className="hover:text-purple-400 transition-colors"
              >
                <Mail className="h-6 w-6" />
              </a>
              <a
                href={`https://${profileData.linkedin}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-purple-400 transition-colors"
              >
                <Linkedin className="h-6 w-6" />
              </a>
              <a
                href={`https://${profileData.github}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-purple-400 transition-colors"
              >
                <Github className="h-6 w-6" />
              </a>
            </div>
          </div>

          <Separator className="my-8 bg-purple-500/20" />

          <div className="text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} {profileData.fullName}. All rights reserved.</p>
            <p className="mt-2 text-sm">Built with React, TypeScript, and Tailwind CSS</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
