
  # AI/ML Portfolio Website

  This is a code bundle for AI/ML Portfolio Website. The original project is available at https://www.figma.com/design/x94QJo4HPAD8Txs1AhX8qe/AI-ML-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  